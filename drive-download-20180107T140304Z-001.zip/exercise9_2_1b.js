
//9.2 1b
var v = [{label: "a"}, 
        {label: "b"},
        {label: "c"},
        {label: "d"},
        {label: "e"},
        { label: "f"}
    ,{ label: "g"}
    ,{ label: "h"}
    ,{ label: "i"}
    ,{ label: "j"}
    ,{ label: "k"}
    ,{ label: "l"}
];

var e = [
    {u:0 ,v:1 ,w:3 },
	 {u:0 ,v:3 ,w:4 },
    {u:0 ,v:2 ,w:5 },
   
    {u:1 ,v:4 ,w:3 },
    {u:1 ,v:5 ,w:6 },
    {u:2 ,v:3 ,w:2 },
    {u:2 ,v:6 ,w:4 },
    {u:3 ,v:4 ,w:1 },
    {u:3 ,v:7 ,w:5 },
    {u:4 ,v:5 ,w:2 },
    {u:4 ,v:8 ,w:4 },
    {u:5 ,v:9 ,w:5 },
    {u:6 ,v:7 ,w:3 },
    {u:6 ,v:10 ,w:6 },
    
    {u:7 ,v:8 ,w:6 },
	{u:7 ,v:10 ,w:7 },
    {u:8 ,v:9 ,w:3 },
    {u:8 ,v:11 ,w:5 },
    {u:9 ,v:11 ,w:9 },
    {u:10,v:11 ,w:8 },

];